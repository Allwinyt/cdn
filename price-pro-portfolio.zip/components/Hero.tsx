'use client'
import { motion } from "framer-motion";
import Image from "next/image";

export default function Hero() {
  return (
    <section className="min-h-screen flex flex-col justify-center items-center text-center px-4">
      <Image src="/logo.png" width={96} height={96} alt="Logo" className="mb-4" />
      <motion.h1
        className="text-5xl font-bold mb-4"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        Captain Price
      </motion.h1>
      <p className="text-xl text-gray-400 mb-6">
        Linux Enjoyer • Minecraft Server Specialist • Fullstack Dev
      </p>
      <a href="#projects" className="bg-white text-black px-4 py-2 rounded hover:bg-gray-200 transition transform hover:scale-105">
        View My Work
      </a>
    </section>
  );
}