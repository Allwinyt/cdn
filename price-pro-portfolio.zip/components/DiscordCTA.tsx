'use client'
import { motion } from "framer-motion";

export default function DiscordCTA() {
  return (
    <section className="px-6 py-20 text-center bg-gray-800">
      <motion.h2
        className="text-3xl font-bold mb-4"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Join Me on Discord
      </motion.h2>
      <p className="text-gray-400 mb-6">Let’s chat, build, and vibe together.</p>
      <a href="https://discord.gg/YOUR_INVITE_LINK" target="_blank" className="bg-indigo-600 px-6 py-3 rounded-lg hover:bg-indigo-500 transition transform hover:scale-105">
        Join Discord
      </a>
    </section>
  );
}