import { motion } from "framer-motion";
import Image from "next/image";
import Hero from "../components/Hero";
import ProjectCard from "../components/ProjectCard";
import DiscordCTA from "../components/DiscordCTA";
import Footer from "../components/Footer";

export default function Home() {
  return (
    <main className="bg-gray-950 text-white min-h-screen">
      <Hero />
      <section className="px-6 py-20 bg-gray-900">
        <h2 className="text-3xl font-bold mb-6">Projects</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <ProjectCard title="VegasXCore" description="Minecraft server hosting with automated deployments." />
          <ProjectCard title="Discord Bot Suite" description="Moderation, music, and utility bot built with Discord.js." />
        </div>
      </section>
      <DiscordCTA />
      <Footer />
    </main>
  );
}